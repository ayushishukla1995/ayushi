package com.cg.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Array{
	public String[] reverseArray(int[] intArray) {
		String strArray[] = new String[intArray.length];
		StringBuilder sb1 = new StringBuilder();
		for (int i = 0; i < intArray.length; i++) {
			strArray[i] = String.valueOf(intArray[i]);
			sb1.append(strArray[i]);
			strArray[i] = sb1.reverse().toString();
			sb1.delete(0, intArray.length);
		}
		Arrays.sort(strArray);
		return strArray; 	
	}
	public List<String> removeSubList(List<String> list1,List<String> list2) {
		list2.removeAll(list1);
		return list2;
	}
	public Map<Integer, Integer> getSquare(int[] arr) {
		Map<Integer, Integer> map = new HashMap<>();
		for (int i : arr)
			map.put(new Integer(i), new Integer(i*i));
		return map;
	}
	public void sortProductList(List<String> list1) {
		Collections.sort(list1);
		for (String str : list1) {
			System.out.println(str);
		}
	}
	
	public static void main(String[] aa) {
		int[] intArray ={12,23,31,15};
		ArrayList<String> list1 = new ArrayList<>();
		ArrayList<String> list2 = new ArrayList<>();
		Array arr = new Array();
		//1. reverse each element and print.
		String[] str = arr.reverseArray(intArray);
		for(int i=0;i<intArray.length;i++)
			System.out.print(str[i]+"\t");
		//2. remove list from another list without using for loop 
		list1.add("t");
		list1.add("a");
		list1.add("n");
		list1.add("u");
		list1.add("j");
		list2.addAll(list1);
		list2.add("k");
		list2.add("u");
		list2.add("m");
		list2.addAll(list1);
		list2.add("a");
		list2.add("r");
		System.out.println(arr.removeSubList(list1, list2));
		//map the number and squares.
		System.out.println(arr.getSquare(intArray));
		
		//sort the arraylist of product name
		arr.sortProductList(list1);
	}
}
