package com.cg.bankAccount;

import java.util.Random;
import java.util.Scanner;

public class Account {
	public long accNum;
	double balance;
	Person person;
	public Account() {
		super();
	}
	public Account(double balance) {
		super();
		this.balance = balance;
	}
	public Account(long accNum, double balance) {
		super();
		this.accNum = accNum;
		this.balance = balance;
	}
	public Account(long accNum, double balance, Person person) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.person = person;
	}
	void deposit(double amount) {
		this.balance +=amount;
	}
	void withdraw(double amount) {
		if(this.balance - amount>=500)
			this.balance -=amount;
		else
			System.out.println("Low balance");
	}
	double getBalance() {
		return this.balance;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (accNum ^ (accNum >>> 32));
		long temp;
		temp = Double.doubleToLongBits(balance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((person == null) ? 0 : person.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accNum != other.accNum)
			return false;
		if (Double.doubleToLongBits(balance) != Double.doubleToLongBits(other.balance))
			return false;
		if (person == null) {
			if (other.person != null)
				return false;
		} else if (!person.equals(other.person))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance + ", person=" + person + "]";
	}
	public static void main(String[] aa) {
		Person person1 = new Person("smith", 35);
		Person person2 = new Person("kathy", 25);
		Random random = new Random();
		//balance = 2000;
		Account account1 = new Account(random.nextLong(),2000, person1);
		//balance = 3000;
		Account account2 = new Account(random.nextLong(), 3000, person2);
		account1.deposit(2000);
		account2.withdraw(2000);
		System.out.println(account1.getBalance());
		System.out.println(account2.getBalance());
		System.out.println("\n"+account1.toString());
		System.out.println(account2.toString());
	}
}
