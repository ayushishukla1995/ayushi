package com.cg.eis.service;

import com.cg.eis.bean.Employee;
public class EmployeeServiceImpl implements EmployeeService{
	public EmployeeServiceImpl(){}
	public  int getMonthlyPremium(Employee emp)	{
		if(emp.getInsuranceScheme().equals("Scheme A"))
			return 5000;
		else if(emp.getInsuranceScheme().equals("Scheme B"))
			return 3000;
		else if(emp.getInsuranceScheme().equals("Scheme C"))
			return 2500;
		else
			return 0;
	}
	public Boolean getCreditHistory(Employee emp){
		if(emp.getSalary()>5000)
			return true;
		return false;
	}
	public int claimHistory(Employee emp){
		return emp.setPreviousClaim(emp.getPreviousClaim());
	}
}
